import logging

def handler(event, context):
    logging.info("Hello world")